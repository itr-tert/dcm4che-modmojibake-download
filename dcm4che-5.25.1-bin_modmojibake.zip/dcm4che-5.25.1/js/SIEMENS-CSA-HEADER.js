DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS CSA HEADER",
"0029xx08":"CSA Image Header Type",
"0029xx09":"CSA Image Header Version",
"0029xx10":"CSA Image Header Info",
"0029xx18":"CSA Series Header Type",
"0029xx19":"CSA Series Header Version",
"0029xx20":"CSA Series Header Info"
});
