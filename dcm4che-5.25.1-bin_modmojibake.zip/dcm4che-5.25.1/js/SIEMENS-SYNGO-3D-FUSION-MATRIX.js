DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS SYNGO 3D FUSION MATRIX",
"0029xx08":"Object Series Instance UID",
"0029xx09":"Model Series Instance UID",
"0029xx10":"Matrix Referenced Series Instance UID"
});
