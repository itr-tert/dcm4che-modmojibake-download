DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS CSA REPORT",
"0029xx08":"Report Type",
"0029xx09":"Report Version",
"0029xx15":"SR Variant",
"0029xx17":"SC SOP Instance UID"
});
