DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips US Imaging DD 036",
"200Dxx15":"?",
"200Dxx16":"?",
"200Dxx17":"?",
"200Dxx18":"?",
"200Dxx19":"?",
"200Dxx20":"?"
});
