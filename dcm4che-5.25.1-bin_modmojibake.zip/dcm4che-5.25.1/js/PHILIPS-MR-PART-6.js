DCM4CHE.elementName.addDictionary({
"privateCreator":"PHILIPS MR/PART 6",
"0019xx10":"?"
});
