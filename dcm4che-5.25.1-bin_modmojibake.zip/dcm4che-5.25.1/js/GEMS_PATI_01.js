DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_PATI_01",
"0011xx10":"Patient Status"
});
