DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS SMS-AX  QUANT 1.0",
"0023xx00":"Horizontal Calibration Pixel Size",
"0023xx01":"Vertical Calibration Pixel Size",
"0023xx02":"Calibration Object",
"0023xx03":"Calibration Object Size",
"0023xx04":"Calibration Method",
"0023xx05":"Filename",
"0023xx06":"Frame Number",
"0023xx07":"Calibration Factor Multiplicity",
"0023xx08":"Calibration Table Object Distance"
});
