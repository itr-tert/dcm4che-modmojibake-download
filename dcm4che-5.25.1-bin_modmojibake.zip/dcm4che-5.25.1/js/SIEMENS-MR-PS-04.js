DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MR PS 04",
"0021xx01":"?"
});
