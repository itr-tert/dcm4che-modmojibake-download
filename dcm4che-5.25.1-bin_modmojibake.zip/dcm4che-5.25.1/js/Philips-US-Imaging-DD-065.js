DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips US Imaging DD 065",
"200Dxx07":"?"
});
