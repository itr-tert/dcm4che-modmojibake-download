DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MI RWVM SUV",
"0041xx01":"SUV Decay Correction Method"
});
