DCM4CHE.elementName.addDictionary({
"privateCreator":"ESOFT_DICOM_ECAT_OWNERCODE",
"0015xx00":"?"
});
