DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS SYNGO FRAME SET",
"0029xx10":"Image Frame Sequence",
"0029xx12":"Type of Progression",
"0029xx14":"Representation Level",
"0029xx16":"Representation Information Sequenc",
"0029xx18":"Number of Representations",
"0029xx20":"Representation Pixel Offse"
});
