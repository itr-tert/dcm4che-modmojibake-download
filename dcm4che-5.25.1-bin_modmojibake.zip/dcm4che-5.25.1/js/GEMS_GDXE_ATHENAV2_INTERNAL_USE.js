DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_GDXE_ATHENAV2_INTERNAL_USE",
"7FDFxx10":"Pixel Data References",
"7FDFxx11":"Pixel Data References (temporary)",
"7FDFxx20":"Auto Push Tag",
"7FDFxx25":"PPS Status"
});
