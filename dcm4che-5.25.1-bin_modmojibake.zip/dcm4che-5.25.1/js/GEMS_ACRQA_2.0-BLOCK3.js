DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_ACRQA_2.0 BLOCK3",
"0023xx00":"CR DRE",
"0023xx10":"CR DRN",
"0023xx20":"CR ORE",
"0023xx30":"CR ORN",
"0023xx40":"CR ORD",
"0023xx50":"CR Cassette Size",
"0023xx60":"CR Machine ID",
"0023xx70":"CR Machine Type",
"0023xx80":"CR Technician Code",
"0023xx90":"CR Energy Subtraction Parameters",
"0023xxF0":"CR Distribution Code",
"0023xxFF":"CR Shutters Applied"
});
