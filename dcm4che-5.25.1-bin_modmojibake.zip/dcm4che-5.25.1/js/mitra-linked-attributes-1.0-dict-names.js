DCM4CHE.elementName.addDictionary({
"privateCreator":"MITRA LINKED ATTRIBUTES 1.0",
"0031xx20":"?"
});
