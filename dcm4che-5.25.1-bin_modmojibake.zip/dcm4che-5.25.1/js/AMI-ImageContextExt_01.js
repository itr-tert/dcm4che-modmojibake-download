DCM4CHE.elementName.addDictionary({
"privateCreator":"AMI ImageContextExt_01",
"3107xxA0":"Window Function",
"3107xxB0":"Window Slope"
});
