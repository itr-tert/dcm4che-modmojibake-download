DCM4CHE.elementName.addDictionary({
"privateCreator":"syngoDynamics",
"0021xxAE":"?",
"0021xxB0":"?",
"0021xxB1":"?"
});
