DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS SYNGO FUNCTION ASSIGNMENT",
"0029xx01":"Data Reference"
});
