DCM4CHE.elementName.addDictionary({
"privateCreator":"agfa/displayableImages",
"2E13xx10":"?",
"2E13xx11":"?"
});
