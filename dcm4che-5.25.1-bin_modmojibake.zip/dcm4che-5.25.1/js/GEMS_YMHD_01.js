DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_YMHD_01",
"0033xx05":"?",
"0033xx06":"?"
});
