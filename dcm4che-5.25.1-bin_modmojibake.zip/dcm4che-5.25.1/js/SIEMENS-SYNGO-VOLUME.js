DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS SYNGO VOLUME",
"0029xx12":"Slices",
"0029xx14":"Volume Histogram",
"0029xx18":"Volume Level",
"0029xx30":"Voxel Spacing",
"0029xx32":"Volume Position (Patient)",
"0029xx37":"Volume Orientation (Patient)",
"0029xx40":"Resampling Flag",
"0029xx42":"Normalization Flag",
"0029xx44":"SubVolume Sequence",
"0029xx46":"Histogram Number Of Bins",
"0029xx47":"Volume Histogram Data"
});
