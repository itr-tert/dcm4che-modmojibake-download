DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips Imaging DD 124",
"1001xx03":"?"
});
