DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MEDCOM OOG",
"0029xx08":"MedCom OOG Type",
"0029xx09":"MedCom OOG Version",
"0029xx10":"MedCom OOG Info"
});
