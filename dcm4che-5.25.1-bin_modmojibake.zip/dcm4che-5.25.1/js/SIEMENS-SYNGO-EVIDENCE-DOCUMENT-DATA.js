DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS SYNGO EVIDENCE DOCUMENT DATA",
"0077xx10":"Evidence Document Template Name",
"0077xx11":"Evidence Document Template Version",
"0077xx20":"Clinical Finding Data",
"0077xx21":"Metadata",
"0077xx30":"Implementation Version",
"0077xx40":"Predecessor",
"0077xx50":"Logical ID",
"0077xx60":"Application Data",
"0077xx70":"Owner Clinical Task Name",
"0077xx71":"Owner Task Name",
"0077xx72":"Owner Supported Templates",
"0077xx80":"Volume Catalog"
});
