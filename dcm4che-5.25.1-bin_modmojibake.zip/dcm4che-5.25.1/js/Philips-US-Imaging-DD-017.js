DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips US Imaging DD 017",
"200Dxx05":"?"
});
