DCM4CHE.elementName.addDictionary({
"privateCreator":"SPI-P-XSB-DCI Release 1",
"0019xx10":"Video Beam Boost",
"0019xx11":"Channel Generating Video Sync",
"0019xx12":"Video Gain",
"0019xx13":"Video Offset",
"0019xx20":"RTD Data Compression Factor"
});
