DCM4CHE.elementName.addDictionary({
"privateCreator":"PHILIPS-MR-1",
"0019xx11":"Chemical Shift Number",
"0019xx12":"Phase Number",
"0021xx01":"Reconstruction Number",
"0021xx02":"Slice Number"
});
