DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MR FOR 06",
"0021xx01":"?"
});
