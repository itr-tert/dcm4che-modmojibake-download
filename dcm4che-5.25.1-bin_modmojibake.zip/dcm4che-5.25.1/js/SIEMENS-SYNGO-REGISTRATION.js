DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS SYNGO REGISTRATION",
"0071xx20":"Registered Image Sequence",
"0071xx21":"Registration Is Validated Flag"
});
