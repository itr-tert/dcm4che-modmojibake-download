DCM4CHE.elementName.addDictionary({
"privateCreator":"APEX_PRIVATE",
"0027xx11":"Bed Position"
});
