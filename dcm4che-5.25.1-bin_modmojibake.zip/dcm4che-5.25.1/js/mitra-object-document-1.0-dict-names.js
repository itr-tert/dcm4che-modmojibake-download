DCM4CHE.elementName.addDictionary({
"privateCreator":"MITRA OBJECT DOCUMENT 1.0",
"0029xx00":"IMPAX Object Document",
"0029xx01":"IMPAX Markup XML Stored"
});
