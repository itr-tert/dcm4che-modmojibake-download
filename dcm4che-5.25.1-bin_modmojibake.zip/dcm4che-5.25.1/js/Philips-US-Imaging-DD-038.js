DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips US Imaging DD 038",
"200Dxx01":"?",
"200Dxx02":"?",
"200Dxx03":"?",
"200Dxx04":"?"
});
