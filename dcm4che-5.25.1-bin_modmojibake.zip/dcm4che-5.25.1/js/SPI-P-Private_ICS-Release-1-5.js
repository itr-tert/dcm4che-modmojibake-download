DCM4CHE.elementName.addDictionary({
"privateCreator":"SPI-P-Private_ICS Release 1;5",
"0029xx50":"?",
"0029xx55":"?"
});
