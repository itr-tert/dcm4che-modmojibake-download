DCM4CHE.elementName.addDictionary({
"privateCreator":"SPI-P-Private-DiDi Release 1",
"0019xx00":"Post Mode String",
"0019xx01":"Post Data",
"0019xx10":"Image Header"
});
