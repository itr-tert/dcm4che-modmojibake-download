DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS CM VA0  LAB",
"0009xx10":"Generator Identification Label",
"0009xx11":"Gantry Identification Label",
"0009xx12":"X-Ray Tube Identification Label",
"0009xx13":"Detector Identification Label",
"0009xx14":"DAS Identification Label",
"0009xx15":"SMI Identification Label",
"0009xx16":"CPU Identification Label",
"0009xx20":"Header Version"
});
