DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS CT VA0  OST",
"6021xx00":"Osteo Contour Comment",
"6021xx10":"Osteo Contour Buffer"
});
