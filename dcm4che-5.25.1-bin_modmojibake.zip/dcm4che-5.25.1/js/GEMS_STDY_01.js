DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_STDY_01",
"0023xx01":"Number Of Series In Study",
"0023xx02":"Number Of Unarchived Series",
"0023xx10":"Reference Image Field",
"0023xx50":"Summary Image",
"0023xx70":"Start Time Secs In First Axial",
"0023xx74":"Number Of Updates To Header",
"0023xx7D":"Indicates If Study Has Complete Info",
"0023xx80":"Has MPPS Related Tags"
});
