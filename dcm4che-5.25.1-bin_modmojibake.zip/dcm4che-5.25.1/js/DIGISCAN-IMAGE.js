DCM4CHE.elementName.addDictionary({
"privateCreator":"DIGISCAN IMAGE",
"0029xx31":"?",
"0029xx32":"?",
"0029xx33":"?",
"0029xx34":"?"
});
