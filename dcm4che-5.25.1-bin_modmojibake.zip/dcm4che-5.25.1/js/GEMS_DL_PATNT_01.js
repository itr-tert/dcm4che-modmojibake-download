DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_DL_PATNT_01",
"0011xx80":"Patient Instance Uid",
"0011xx81":"Last Study Number",
"0011xx82":"Patient Repaired",
"0011xx83":"Lock Demographics"
});
