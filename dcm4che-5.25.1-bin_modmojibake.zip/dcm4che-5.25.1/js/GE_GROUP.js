DCM4CHE.elementName.addDictionary({
"privateCreator":"GE_GROUP",
"6005xx10":"?"
});
