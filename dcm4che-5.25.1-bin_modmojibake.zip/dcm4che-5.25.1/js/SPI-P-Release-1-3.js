DCM4CHE.elementName.addDictionary({
"privateCreator":"SPI-P Release 1;3",
"0029xx00":"Image Enhancement ID",
"0029xx01":"Image Enhancement",
"0029xx02":"Convolution ID",
"0029xx03":"Convolution Type",
"0029xx04":"Convolution Kernel Size ID",
"0029xx05":"Convolution Kernel Size",
"0029xx06":"Convolution Kernel",
"0029xx0C":"Enhancement Gain",
"0029xx1E":"Image Enhancement Enable Status",
"0029xx1F":"Image Enhancement Select Status"
});
