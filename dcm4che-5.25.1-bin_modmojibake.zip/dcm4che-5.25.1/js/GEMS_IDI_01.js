DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_IDI_01",
"0073xx20":"Height Map Plane Distance",
"0073xx21":"Height Map Plane Offset",
"0073xx30":"Height Map Plane Indices",
"0073xx31":"X Map Plane Indices",
"0073xx32":"Y Map Plane Indices",
"0073xx40":"Central Projection Detector Secondary Angle",
"0073xx50":"Detector Active Dimensions"
});
