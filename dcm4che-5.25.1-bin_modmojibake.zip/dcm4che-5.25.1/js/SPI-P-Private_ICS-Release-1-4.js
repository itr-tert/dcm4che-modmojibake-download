DCM4CHE.elementName.addDictionary({
"privateCreator":"SPI-P-Private_ICS Release 1;4",
"0029xxD6":"?",
"0029xxD7":"?",
"0029xxD8":"?",
"0029xxD9":"?",
"0029xxDA":"?",
"0029xxDC":"?",
"0029xxDD":"?",
"0029xxE0":"?"
});
