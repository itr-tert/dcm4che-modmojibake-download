DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips US Imaging DD 037",
"200Dxx02":"?",
"200Dxx03":"?",
"200Dxx04":"?",
"200Dxx06":"?",
"200Dxx08":"?",
"200Dxx0A":"?",
"200Dxx0B":"?",
"200Dxx0C":"?",
"200Dxx0D":"?",
"200Dxx0E":"?",
"200Dxx0F":"?"
});
