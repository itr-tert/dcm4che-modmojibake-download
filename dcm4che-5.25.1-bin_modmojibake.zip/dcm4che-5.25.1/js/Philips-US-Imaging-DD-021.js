DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips US Imaging DD 021",
"200Dxx07":"?"
});
