DCM4CHE.elementName.addDictionary({
"privateCreator":"KRETZ_US",
"7FE1xx01":"?"
});
