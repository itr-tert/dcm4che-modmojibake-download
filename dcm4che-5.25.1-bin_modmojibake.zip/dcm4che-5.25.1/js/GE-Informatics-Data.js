DCM4CHE.elementName.addDictionary({
"privateCreator":"GE Informatics Data",
"3003xx00":"?",
"3003xx01":"?",
"3003xx02":"?",
"3003xx03":"?",
"3003xx04":"?",
"3003xx05":"?",
"3003xx06":"?"
});
