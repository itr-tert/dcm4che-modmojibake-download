DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips US Imaging DD 046",
"200Dxx17":"?",
"200Dxx19":"?"
});
